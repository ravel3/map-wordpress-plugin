# Changelog

## [2.0.0] - 2024-11-06

### Added
- Wsparcie dla bazy danych WordPress zamiast plików
- Obsługa wielu map z identyfikatorami liczbowymi
- Nazwy medali wyświetlane w popupach
- Panel administracyjny do zarządzania mapami i medalami
- Historia pobrań medali w bazie danych
- Atomowe transakcje dla bezpieczeństwa danych
- Walidacja adresów e-mail po stronie serwera i klienta
- Automatyczna instalacja Docker z przykładowymi danymi

### Changed
- Przepisano system przechowywania z plików na bazę danych
- Ulepszone bezpieczeństwo z nonce verification
- Zoptymalizowano zapytania SQL z proper indexes
- Modernizacja interfejsu użytkownika z responsive design

### Technical
- Struktura tabel: maps, medals, medal_status, history
- Foreign key constraints dla integralności danych
- WordPress AJAX API z secure endpoints
- Leaflet.js 1.9.4 dla map interaktywnych
- Docker Compose dla łatwego wdrożenia

## [1.0.0] - 2024-10-15

### Added
- Podstawowa funkcjonalność map medalów
- System plików JSON do przechowywania danych
- Leaflet.js integration
- WordPress shortcode support
